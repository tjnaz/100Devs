# Flexbox Crash Course

A Pen created on CodePen.io. Original URL: [https://codepen.io/bradtraversy/pen/JjrzzOW](https://codepen.io/bradtraversy/pen/JjrzzOW).

